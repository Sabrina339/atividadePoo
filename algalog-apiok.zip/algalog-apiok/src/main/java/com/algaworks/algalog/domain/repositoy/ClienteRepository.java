package com.algaworks.algalog.domain.repositoy;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import javax.validation.Valid;
import com.algaworks.algalog.domain.model.Cliente;




@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

	List<Cliente> findByNome(String nome);
	List<Cliente> findByNomeContaining(String nome);
	@Valid
	Cliente salvar(@Valid Cliente cliente);
	public void excluir(Long clienteId);
}
