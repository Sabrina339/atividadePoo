package com.algaworks.algalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgalogApiokApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgalogApiokApplication.class, args);
	}

}
